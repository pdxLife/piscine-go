# Server requirements

**Linux compatible only**

| Component | Recommended specifications        |
| --------- | --------------------------------- |
| Processor | 16 threads x86-64 (64 bits)       |
| Memory    | 64 GB ECC DDR4 2133 Mhz frequency |
| Disk      | 500 GB SSD NVMe                   |
