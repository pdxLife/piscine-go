# Tasks

-   [x] Install, connect, check the server and the HP clients (_Alem_, _Vitalii_)
-   [x] Check the settings of the virtual machine (_01_, _Vitalii_)
-   [x] Install the server (_01_, _Vitalii_)
-   [x] Tests & benchmark of the server (_01_)
-   [x] Test the [OS deployment](https://github.com/01-edu/public/blob/master/docs/os-deployment.md) (_01_, _Vitalii_)
-   [ ] Write process documentation (_01_, _Alem_, _Vitalii_)
-   [ ] Ensure the tester only works inside the school (_01_, _Alem_)
-   [ ] Ensure the exam app works as expected (_01_, _Alem_)
-   [ ] Test the entire piscine (_01_, _Alem_)
