## cl-camp1

### Instructions

A little voice speaks in your head:

"Now that you know who you are. You need to remember what you can do..."

The instincts are coming back...

Put in a file `mastertheLS` the command line that will:

-   list the files and folders of the current folder.
-   Ignore the hidden files, the "." and the "..".
-   Separates the resuls with commas.
-   Order them by ascending order of creation date.
-   Have the folders have a `/` in front of them.

### Hint

Read the man...
