## cl-camp1

### Instructions

Une petite voix dans votre esprit vous dit:

"Maintenant que tu sais qui tu es. Tu dois te souvenir de ce que tu peux faire..."

Les instincts resurgissent...

Mettez dans un fichier `mastertheLS` la ligne de commande qui:

-   listera les fichiers et dossiers dans le dossier courant.
-   Ignorera les fichiers cachés, le "." et le "..".
-   Separarera le resultat avec des virgules.
-   Les triera pas ordre croissant de date de création.
-   Placera un `/` en face des dossiers.

### Indice

Lisez le man...
