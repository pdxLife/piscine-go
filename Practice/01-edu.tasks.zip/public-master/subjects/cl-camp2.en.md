## cl-camp2

### Instructions

"keep training ..."

Create a file `r`, which shows `R` on a line when the `cat` command is executed

A line is a sequence of characters preceding the [end of line](https://en.wikipedia.org/wiki/Newline) character (`'\n'`).

### Usage

```console
student@ubuntu:~/piscine-go/test$ cat -e r
R$
student@ubuntu:~/piscine-go/test$
```
