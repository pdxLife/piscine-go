## cl-camp2

### Instructions

"Continue l'entrainement ..."

Créez un fichier `r`, qui affiche `R` sur une ligne quand la commande `cat` est exécutée.

Une ligne est une suite de caractères précédant le caractère [fin de ligne](https://en.wikipedia.org/wiki/Newline) (`'\n'`).

### Utilisation

```console
student@ubuntu:~/piscine-go/test$ cat -e r
R$
student@ubuntu:~/piscine-go/test$
```
