## cl-camp3

### Instructions

"start looking ..."

Create a file `look`, which will look for and show, in the current directory and its sub-folders all the files :

-   starting with an `a` and,
-   all the files ending with a `z` and,
-   all files starting with `z` and ending with `a!`.

### Hint

Read the `find` man...
