## cl-camp3

### Instructions

"commences à chercher ..."

Créer un fichier `look`, qui cherchera et montrera, dans le répertoire courant et ses sous-répertoires, tous les fichiers qui:

-   commence avec `a` et,
-   tous les fichiers qui se terminent avec `z` et,
-   tous les fichiers qui commencent avec `z` et qui se finissent avec `a!`.

### Indice

Lisez le man de `find`...
