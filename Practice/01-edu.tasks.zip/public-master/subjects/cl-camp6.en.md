## cl-camp6

### Instructions

"Now, do your inventory"

Create a file `countfiles.sh`, which will print the number **(and only the number)** of regular files and folders contained in the current directory and its sub-folders :

### Usage

```console
student@ubuntu:~/piscine-go/test$ ./countfiles.sh | cat -e
12$
student@ubuntu:~/piscine-go/test$
```
