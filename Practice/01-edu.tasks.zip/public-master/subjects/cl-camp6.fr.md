## cl-camp6

### Instructions

"Maintenant, fais ton inventaire"

Créer un fichier `countfiles.sh`, qui affichera le nombre **(et seulement le nombre)** de fichiers réguliers et répertoires contenu dans le répertoire courant et ses sous-répertoires :

### Utilisation

```console
student@ubuntu:~/piscine-go/test$ ./countfiles.sh | cat -e
12$
student@ubuntu:~/piscine-go/test$
```
