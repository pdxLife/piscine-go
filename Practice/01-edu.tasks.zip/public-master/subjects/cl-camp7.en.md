## cl-camp7

### Instructions

"Be accurate"

Create a file `"\?$*'ChouMi'*$?\"` that will contain "01" and **nothing else**.

### Usage

```console
student@ubuntu:~/piscine-go/test$ ls | cat -e
"\?$*'ChouMi'*$?\"$
student@ubuntu:~/piscine-go/test$
```
