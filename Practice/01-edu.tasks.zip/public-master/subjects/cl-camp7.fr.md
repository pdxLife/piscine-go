## cl-camp7

### Instructions

"Sois précis"

Créer un fichier `"\?$*'ChouMi'*$?\"` qui contiendra "01" et **rien d'autre**.

### Utilisation

```console
student@ubuntu:~/piscine-go/test$ ls | cat -e
"\?$*'ChouMi'*$?\" $
student@ubuntu:~/piscine-go/test$
```
