## cl-camp8

### Instructions

"pick your equipment"

Write a command line in a `skip.sh` file that prints the result of a `ls -l` skipping 1 line out of 2, starting with the **first** one.

### Hint

`awk` or `sed` can do the job.
