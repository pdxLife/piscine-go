## cl-camp8

### Instructions

"Choisis ton équipement"

écrire une ligne dans un fichier `skip.sh` qui affiche le résultat d'un `ls -l` qui saute 1 ligne sur 2, en commençant par la **première**.

### Indice

`awk` ou `sed` peuvent faire le travail.
