## countdown

### Instructions

Écrire un programme qui affiche les chiffres dans l'ordre décroissant sur une seule ligne, suivi par un retour à la ligne (`'\n'`).

### Utilisation

```console
student@ubuntu:~/piscine-go/test$ go build
student@ubuntu:~/piscine-go/test$ ./test
9876543210
student@ubuntu:~/piscine-go/test$
```
