## displayalpham

### Instructions

Write a program that displays the alphabet, with even letters in uppercase, and
odd letters in lowercase, followed by a newline (`'\n'`).

### Usage

```console
student@ubuntu:~/piscine-go/displayalpham$ go build
student@ubuntu:~/piscine-go/displayalpham$ ./displayalpham | cat -e
aBcDeFgHiJkLmNoPqRsTuVwXyZ$
student@ubuntu:~/piscine-go/displayalpham$
```
