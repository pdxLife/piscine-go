## displayalpham

### Instructions

Écrire un programme qui affiche l'alphabet, avec les lettres paires en majuscule, et les lettres impaires en minuscule, suivi d'un retour à la ligne (`'\n'`).

### Utilisation

```console
student@ubuntu:~/piscine-go/displayalpham$ go build
student@ubuntu:~/piscine-go/displayalpham$ ./displayalpham | cat -e
aBcDeFgHiJkLmNoPqRsTuVwXyZ$
student@ubuntu:~/piscine-go/displayalpham$
```
