## displayalrevm

### Instructions

Write a program that displays the alphabet in reverse, with even letters in
uppercase, and odd letters in lowercase, followed by a newline (`'\n'`).

### Usage

```console
student@ubuntu:~/piscine-go/displayalrevm$ go build
student@ubuntu:~/piscine-go/displayalrevm$ ./displayalrevm | cat -e
zYxWvUtSrQpOnMlKjIhGfEdCbA$
student@ubuntu:~/piscine-go/displayalrevm$
```
