## displayalrevm

### Instructions

Écrire un programme qui affiche l'alphabet à l'envers, avec les lettres paires en majuscule, et les lettres impaires en minuscule, suivi d'un retour à la ligne (`'\n'`).

### Utilisation

```console
student@ubuntu:~/piscine-go/displayalrevm$ go build
student@ubuntu:~/piscine-go/displayalrevm$ ./displayalrevm | cat -e
zYxWvUtSrQpOnMlKjIhGfEdCbA$
student@ubuntu:~/piscine-go/displayalrevm$
```
