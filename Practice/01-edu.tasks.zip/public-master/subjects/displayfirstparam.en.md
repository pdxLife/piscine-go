## displayfirstparam

### Instructions

Write a program that takes `string` as arguments, and displays its first argument.

### Usage

```console
student@ubuntu:~/piscine-go/test$ go build
student@ubuntu:~/piscine-go/test$ ./test hello there
hello
student@ubuntu:~/piscine-go/test$ ./test "hello there" how are you
hello there
student@ubuntu:~/piscine-go/test$ ./test
student@ubuntu:~/piscine-go/test$
```
