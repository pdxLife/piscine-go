## displayfirstparam

### Instructions

Écrire un programme qui prend des `string` comme arguments, et qui affiche le premier argument.

### Utilisation

```console
student@ubuntu:~/piscine-go/test$ go build
student@ubuntu:~/piscine-go/test$ ./test hello there
hello
student@ubuntu:~/piscine-go/test$ ./test "hello there" how are you
hello there
student@ubuntu:~/piscine-go/test$ ./test
student@ubuntu:~/piscine-go/test$
```
