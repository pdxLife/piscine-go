## displaylastparam

### Instructions

Write a program that takes `string` as arguments, and displays its last argument.

### Expected output

```console
student@ubuntu:~/piscine-go/test$ go build
student@ubuntu:~/piscine-go/test$ ./test hello there
there
student@ubuntu:~/piscine-go/test$ ./test "hello there" how are you
you
student@ubuntu:~/piscine-go/test$ ./test "hello there"
hello there
student@ubuntu:~/piscine-go/test$ ./test
student@ubuntu:~/piscine-go/test$
```
