## firstruneprog

### Instructions

Écrire un programme qui reçoit une `string` et qui retourne la première `rune` de cette `string`.

### Utilisation :

```console
student@ubuntu:~/piscine-go/firstruneprog$ go build
student@ubuntu:~/piscine-go/firstruneprog$ ./firstruneprog "this is not happening"
t
student@ubuntu:~/piscine-go/firstruneprog$ ./firstruneprog "hello" | cat-e
h$
student@ubuntu:~/piscine-go/firstruneprog$ ./firstruneprog "this" "is" "not" "happening"
student@ubuntu:~/piscine-go/firstruneprog$
student@ubuntu:~/piscine-go/firstruneprog$ ./firstruneprog
student@ubuntu:~/piscine-go/firstruneprog$
```
