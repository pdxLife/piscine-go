## hello

### Instructions

Write a program that displays "Hello World!" followed by a newline (`'\n'`).

### Usage

```console
student@ubuntu:~/piscine-go/test$ go build
student@ubuntu:~/piscine-go/test$ ./test
Hello World!
student@ubuntu:~/piscine-go/test$
```
