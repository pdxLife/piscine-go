## hello

### Instructions

Écrire un programme qui affiche "Hello World!" suivi d'un retour à la ligne (`'\n'`).

### Utilisation

```console
student@ubuntu:~/piscine-go/test$ go build
student@ubuntu:~/piscine-go/test$ ./test
Hello World!
student@ubuntu:~/piscine-go/test$
```
