## itoa

### Instructions

-   Write a function that simulates the behaviour of the `Itoa` function in Go. `Itoa` transforms a number represented as an`int` in a number represented as a `string`.

-   For this exercise the handling of the signs + or - **does have** to be taken into account.

## Expected function

```go
func Itoa(n int) string {

}
```
