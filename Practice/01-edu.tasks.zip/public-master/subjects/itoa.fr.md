## itoa

### Instructions

-   Écrire une fonction qui reproduit le comportement de la fonction `Itoa` en Go. `Itoa` transforme un nombre représenté en `int` (entier) en `string` (chaîne de caractères).

-   Pour cet exercice la gestion des signes + ou - **doit être** prise en compte.

## Fonction attendue

```go
func Itoa(n int) string {

}
```
