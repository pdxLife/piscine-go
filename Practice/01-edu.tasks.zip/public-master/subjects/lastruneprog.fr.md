## lastruneprog

### Instructions

Écrire un programme qui reçoit une `string` en paramètre et qui retourne la dernière `rune` de la `string`.

### Utilisation :

```console
student@ubuntu:~/piscine-go/firstruneprog$ go build
student@ubuntu:~/piscine-go/firstruneprog$ ./firstruneprog "this is not happening"
g
student@ubuntu:~/piscine-go/firstruneprog$ ./firstruneprog "hello" | cat -e
o$
student@ubuntu:~/piscine-go/firstruneprog$ ./firstruneprog "this" "is" "not" "happening"
student@ubuntu:~/piscine-go/firstruneprog$
student@ubuntu:~/piscine-go/firstruneprog$ ./firstruneprog
student@ubuntu:~/piscine-go/firstruneprog$
```
