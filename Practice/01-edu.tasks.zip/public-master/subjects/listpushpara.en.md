## listpushpara

### Instructions

Write a program that creates a new linked list and includes each command-line argument in to the list.

-   The first argument should be at the end of the list

And its output :

```console
student@ubuntu:~/piscine-go/test$ go build
student@ubuntu:~/piscine-go/test$ ./listpushparams choumi is the best cat
cat
best
the
is
choumi
student@ubuntu:~/piscine-go/test$
```
