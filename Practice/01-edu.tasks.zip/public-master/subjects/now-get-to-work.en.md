## now-get-to-work

### Instructions

"Something terrible happened"

clone this repo : https://github.com/01-edu/the-final-cl-test

Submit your solution in the file `my_answer.sh` that will print it when executed.

### Utilisation

```console
student@ubuntu:~/piscine-go/test$ ./my_answer.sh | cat -e
John Doe$
student@ubuntu:~/piscine-go/test$
```

### Hint

"You could combine `head` and `tail`s..."
