## now-get-to-work

### Instructions

"Quelque chose de terrible est arrivé"

Faîtes un clone de repo : https://github.com/01-edu/the-final-cl-test

Rendez votre solution dans un fichier `my_answer.sh` qui l'affichera quand exécuté.

### Usage

```console
student@ubuntu:~/piscine-go/test$ ./my_answer.sh | cat -e
John Doe$
student@ubuntu:~/piscine-go/test$
```

### Hint

"Vous pouvez combinez `head` et `tail`s..."
