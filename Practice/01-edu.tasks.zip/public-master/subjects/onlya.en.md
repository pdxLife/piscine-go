## onlya

### Instructions

Write a program that displays a `a` character on the standard output. (and nothing else)
