## onlya

### Instructions

Écrire un programme qui affiche un caractère `a` sur la sortie standard. (et rien d'autre)
