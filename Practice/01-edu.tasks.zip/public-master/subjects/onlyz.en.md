## onlyz

### Instructions

Write a program that displays a `z` character on the standard output. (and nothing else)
