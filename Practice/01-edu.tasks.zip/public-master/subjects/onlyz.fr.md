## onlyz

### Instructions

Écrire un programme qui affiche un caractère `z` sur la sortie standard. (et rien d'autre)
