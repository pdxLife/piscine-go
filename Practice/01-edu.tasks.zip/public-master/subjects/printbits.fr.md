## printbits

### Instructions

Écrire un programme qui prend un nombre en argument, et qui l'affiche en valeur binaire **sans newline à la fin**.

-   Si l'argument n'est pas un nombre le programme doit afficher `00000000`.

### Expected output :

```console
student@ubuntu:~/printbits$ go build
student@ubuntu:~/printbits$ ./printbits 1
00000001student@ubuntu:~/printbits$
student@ubuntu:~/printbits$ ./printbits 192
11000000student@ubuntu:~/printbits$
student@ubuntu:~/printbits$ ./printbits a
00000000student@ubuntu:~/printbits$
student@ubuntu:~/printbits$ ./printbits 1 1
student@ubuntu:~/printbits$ ./printbits
student@ubuntu:~/printbits$
```
