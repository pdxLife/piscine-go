## printcomb2

### Instructions

Write a [function](TODO-LINK) that prints in ascending order on a single line all possible combinations of two different two-digit numbers.

These combinations are separated by a comma and a space.

### Expected function

```go
func PrintComb2() {

}
```

### Usage

Here is a possible [program](TODO-LINK) to test your function :

```go
package main

import piscine ".."

func main() {
	piscine.PrintComb2()
}
```

This is the incomplete output :

```console
student@ubuntu:~/piscine-go/test$ go build
student@ubuntu:~/piscine-go/test$ ./test
00 01, 00 02, 00 03, ..., 00 98, 00 99, 01 02, 01 03, ..., 97 98, 97 99, 98 99
student@ubuntu:~/piscine-go/test$
```
