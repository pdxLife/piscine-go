## printdigits

### Instructions

Write a program that prints the decimal digits in ascending order (from `0` to `9`) on a single line.

A line is a sequence of characters preceding the end of line character (`'\n'`).

### Usage

```console
student@ubuntu:~/piscine-go/printdigits$ go build
student@ubuntu:~/piscine-go/printdigits$ ./printdigits
0123456789
student@ubuntu:~/piscine-go/printdigits$
```
