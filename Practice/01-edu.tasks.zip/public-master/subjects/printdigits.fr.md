## printdigits

### Instructions

Écrire un [programme](TODO-LINK) qui affiche les chiffres décimaux dans l'ordre croissant (de `0` à `9`) sur une seule ligne.

Une ligne est une suite de caractères précédant le caractère [fin de ligne](https://en.wikipedia.org/wiki/Newline) (`'\n'`).

### Utilisation

```console
student@ubuntu:~/piscine-go/printdigits$ go build
student@ubuntu:~/piscine-go/printdigits$ ./printdigits
0123456789
student@ubuntu:~/piscine-go/printdigits$
```
