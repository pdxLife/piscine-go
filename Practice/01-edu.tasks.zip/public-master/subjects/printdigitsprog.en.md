## printdigitsprog

### Instructions

Write a [program](TODO-LINK) that prints the decimal digits in ascending order (from `0` to `9`) on a single line.

A line is a sequence of characters preceding the [end of line](https://en.wikipedia.org/wiki/Newline) character (`'\n'`).

### Usage

```console
student@ubuntu:~/printdigitsprog$ go build
student@ubuntu:~/printdigitsprog$ ./main
0123456789
student@ubuntu:~/printdigitsprog$
```