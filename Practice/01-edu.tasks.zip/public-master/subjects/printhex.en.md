## printhex

### Instructions

Write a program that takes a positive (or zero) number expressed in base 10, and displays it in base 16 (with lowercase letters) followed by a newline (`'\n'`).

-   If the number of parameters is different from 1, the program displays a newline.

### Usage

```console
student@ubuntu:~/piscine-go/test$ go build
student@ubuntu:~/piscine-go/test$ ./test "10"
a
student@ubuntu:~/piscine-go/test$ ./test "255"
ff
student@ubuntu:~/piscine-go/test$ ./test "5156454"
4eae66
student@ubuntu:~/piscine-go/test$

student@ubuntu:~/piscine-go/
```
