## printparams

### Instructions

Write a **program** that prints the arguments received in the command line.

Example of output :

```console
student@ubuntu:~/piscine-go/test$ go build
student@ubuntu:~/piscine-go/test$ ./printparams choumi is the best cat
choumi
is
the
best
cat
student@ubuntu:~/piscine-go/test$
```
