## printparams

### Instructions

Écrire un **programme** qui affiche les arguments en ligne de commande.

Exemple de résultat :

```console
student@ubuntu:~/piscine-go/test$ go build
student@ubuntu:~/piscine-go/test$ ./printparams choumi is the best cat
choumi
is
the
best
cat
student@ubuntu:~/piscine-go/test$
```
