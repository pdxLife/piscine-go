## printprogramname

### Instructions

Write a **program** that prints the name of the program.

Example of output :

```console
student@ubuntu:~/piscine-go/printprogramname$ go build main.go
student@ubuntu:~/piscine-go/printprogramname$ ./main
./main
student@ubuntu:~/piscine-go/printprogramname$
```
