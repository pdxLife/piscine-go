## printprogramname

### Instructions

Écrire un **programme** qui affiche le nom du programme.

Exemple de résultat :

```console
student@ubuntu:~/piscine-go/printprogramname$ go build main.go
student@ubuntu:~/piscine-go/printprogramname$ ./main
./main
student@ubuntu:~/piscine-go/printprogramname$
```
