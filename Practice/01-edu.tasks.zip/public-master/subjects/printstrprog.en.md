## printstrprog

### Instructions

-   Write a program that prints one by one the characters of a `string` passed as an argument of the program.

### Expected output :

```console
student@ubuntu:~/piscine-go/printstrprog$ go build
student@ubuntu:~/piscine-go/printstrprog$ ./printstrprog "Hello World!" | cat -e
Hello World!$
student@ubuntu:~/piscine-go/printstrprog$ ./printstrprog
student@ubuntu:~/piscine-go/printstrprog$
student@ubuntu:~/piscine-go/printstrprog$ ./printstrprog "Hello" "World"
student@ubuntu:~/piscine-go/printstrprog$
```
