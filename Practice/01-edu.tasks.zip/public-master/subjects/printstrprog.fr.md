## printstrprog

### Instructions

-   Écrire un programme qui affiche un à un les caractères d'une `string` passée en argument du programme.

### Utilisation :

```console
student@ubuntu:~/piscine-go/printstrprog$ go build
student@ubuntu:~/piscine-go/printstrprog$ ./printstrprog "Hello World!" | cat -e
Hello World!$
student@ubuntu:~/piscine-go/printstrprog$ ./printstrprog
student@ubuntu:~/piscine-go/printstrprog$
student@ubuntu:~/piscine-go/printstrprog$ ./printstrprog "Hello" "World"
student@ubuntu:~/piscine-go/printstrprog$
```
