## revparams

### Instructions

Write a **program** that prints the arguments received in the command line in a reverse order.

Example of output :

```console
student@ubuntu:~/piscine-go/test$ go build
student@ubuntu:~/piscine-go/test$ ./revparams choumi is the best cat
cat
best
the
is
choumi
student@ubuntu:~/piscine-go/test$
```
