## revparams

### Instructions

Écrire un **programme** qui affiche les arguments en ligne de commande en ordre inverse.

Exemple de résultat :

```console
student@ubuntu:~/piscine-go/test$ go build
student@ubuntu:~/piscine-go/test$ ./revparams choumi is the best cat
cat
best
the
is
choumi
student@ubuntu:~/piscine-go/test$
```
