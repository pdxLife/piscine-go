## strlenprog

### Instructions

-   Écrire un programme qui compte le nombre de caractères d'une `string` et qui retourne le nombre trouvé.

-   Si le programme reçoit plusieurs ou aucun arguments il ne doit rien afficher.

### Utilisation :

```console
student@ubuntu:~/piscine-go/strlenprog$ go build
student@ubuntu:~/piscine-go/strlenprog$ ./strlenprog "hello" | cat -e
5$
student@ubuntu:~/piscine-go/strlenprog$ ./strlenprog
student@ubuntu:~/piscine-go/strlenprog$
student@ubuntu:~/piscine-go/strlenprog$ ./strlenprog "hello" "how are you"
student@ubuntu:~/piscine-go/strlenprog$
```
