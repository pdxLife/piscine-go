## strrevprog

### Instructions

-   Write a program that reverses a `string` and prints it in the standard output.

### Expected output :

```console
student@ubuntu:~/piscine-go/strrevprog$ go build
student@ubuntu:~/piscine-go/strrevprog$ ./strrevprog "Hello World!" | cat -e
!dlroW olleH$
student@ubuntu:~/piscine-go/strrevprog$ ./strrevprog
student@ubuntu:~/piscine-go/strrevprog$
```
