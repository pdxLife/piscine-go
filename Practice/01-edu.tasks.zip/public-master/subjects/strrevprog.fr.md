## strrevprog

### Instructions

-   Écrire un programme qui inverse une `string` et qui l'affiche dans la sortie standard.

### Utilisation :

```console
student@ubuntu:~/piscine-go/strrevprog$ go build
student@ubuntu:~/piscine-go/strrevprog$ ./strrevprog "Hello World!" | cat -e
!dlroW olleH$
student@ubuntu:~/piscine-go/strrevprog$ ./strrevprog
student@ubuntu:~/piscine-go/strrevprog$
```
