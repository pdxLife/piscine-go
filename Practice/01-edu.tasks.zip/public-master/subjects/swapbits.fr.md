## swapbits

### Instructions

Écrire une fonction qui prend un `byte`, échange ses moitiés (comme sur l'exemple) et retourne le résultat.

### Fonction attendue

```go
func SwapBits(octet byte) byte {

}
```

Exemple:

1 byte

---

```
0100 | 0001
    \ /
    / \
0001 | 0100
```
