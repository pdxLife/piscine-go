## switchcase

### Instructions

Écrire un programme qui prend une `string` et qui inverses les majuscules en minuscules et vice-versa.

-   Tout autre caractère reste inchangé.

-   Le résultat doit être suivi d'un retour à la ligne (`'\n'`).

-   Si le nombre d'arguments est différent de 1, le programme affiche un retour à la ligne (`'\n'`).

### Utilisation

```console
student@ubuntu:~/piscine-go/test$ go build
student@ubuntu:~/piscine-go/test$ ./test "SometHingS iS WronG"
sOMEThINGs Is wRONg
student@ubuntu:~/piscine-go/test$ ./test

student@ubuntu:~/piscine-go/test$
```
