## to-git-or-not-to-git-?

### Instructions

Write in a file `to-git-or-not-to-git.sh` the command that isolates your `gitHub id`.
Only the numbers will appear.

### Usage

```console
$ ./to-git-or-not-to-git.sh
231748
$
`
```
