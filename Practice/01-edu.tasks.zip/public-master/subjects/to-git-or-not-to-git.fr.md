## to-git-or-not-to-git-?

### Instructions

Écrire dans un fichier `to-git-or-not-to-git.sh` la commande qui isoles votre `gitHub id`.
Seulement les chiffres apparaitront.

### Utilisation

```console
$ ./to-git-or-not-to-git.sh
231748
$
`
```
