## toupper

### Instructions

Écrire une fonction qui met en majuscule chaque lettre d'une `string`.

### Fonction attendue

```go
func ToUpper(s string) string {

}
```

### Utilisation

Voici un éventuel [programme](TODO-LINK) pour tester votre fonction :

```go
package main

import (
	"fmt"
	piscine ".."
)

func main() {
	fmt.Println(piscine.ToUpper("Hello! How are you?"))
}
```

Et son résultat :

```console
student@ubuntu:~/piscine-go/test$ go build
student@ubuntu:~/piscine-go/test$ ./test
HELLO! HOW ARE YOU?
student@ubuntu:~/piscine-go/test$
```
