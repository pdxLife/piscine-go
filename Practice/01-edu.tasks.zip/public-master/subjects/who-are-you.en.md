## who-are-you

### Instructions

"You just woke up in a dark alley...
You can not remember who you are...
The only though that comes to your mind is a tag that says: `subject Id: 70`"

Create the file `who-are-you.sh` which will remind you who you are by showing your name only.

-   Where to look : https://raw.githubusercontent.com/kigiri/superhero-api/master/api/all.json

-   What to use : `curl` and `jq`
