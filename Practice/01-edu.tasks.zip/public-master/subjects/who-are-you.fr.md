## who-are-you

### Instructions

"Vous venez de vous réveillez dans une allée sombre...
Vous n'arrivez pas à vous souvenir qui vous êtes...
Tout ce qui vous vient à l'esprit est une étiquette sur laquelle est écrite: `subject Id: 70`"

Créer le fichier `who-are-you.sh` qui vous rappellera qui vous êtes en affichant votre Nom seulement.

-   Où chercher : https://raw.githubusercontent.com/kigiri/superhero-api/master/api/all.json

-   Quoi utiliser : `curl` et `jq`
