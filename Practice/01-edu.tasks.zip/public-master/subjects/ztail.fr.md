## ztail

### Instructions

Écrire un programme `ztail` qui a le même comportement que la ligne de commande `tail`, mais qui prend au moins 1 fichier comme argument.

-   La seule option qui doit être géré est `-c`. Cette option sera utilisé dans tous les tests.

-   Pour ce programme le package "os" peut être utilisé.

-   Pour que le programme passe les tests la convention pour le retour code de programme en systémes Unix devra être suivi(voir os.Exit).

-   Pour plus d'informtations consulter la page du man de `tail`.
