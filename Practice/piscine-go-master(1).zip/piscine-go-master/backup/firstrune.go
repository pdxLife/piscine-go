package piscine

func FirstRune(s string) rune {
	strToRune := []rune(s)
	return strToRune[0]
}
