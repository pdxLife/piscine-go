package piscine

func NRune(s string, n int) rune {
	strToRune := []rune(s)
	n2 := n-1
	return strToRune(n2)
}
