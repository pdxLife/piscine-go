package piscine

func PointOne(n *int) {
	*n = 1
}
